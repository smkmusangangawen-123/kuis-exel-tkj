# Kuis Microsoft Excel - Kelas 11 TKJ
Kuis interaktif berbasis web untuk siswa **SMK Muhammadiyah Ngawen**.

## 📘 Cara Menggunakan
1. Buka file `index.html` di browser (Chrome / Safari / Edge)
2. Masukkan nama siswa di awal
3. Jawab soal dan lihat hasil akhir secara otomatis

## 🌐 Untuk diunggah ke GitHub Pages
1. Buat repository baru di GitHub (Public)
2. Upload semua isi folder ini (index.html, logo-smk.png, README.md)
3. Masuk ke Settings → Pages → pilih Source: `main` branch dan root (`/`)
4. Tunggu beberapa detik, lalu akses melalui:
   ```
   https://<username>.github.io/kuis-excel-tkj/
   ```
